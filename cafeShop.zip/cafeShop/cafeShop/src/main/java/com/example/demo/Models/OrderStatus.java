package com.example.demo.Models;

public enum OrderStatus {
    COMPLETED
    // PEDDING , 
    // CANCELED
}